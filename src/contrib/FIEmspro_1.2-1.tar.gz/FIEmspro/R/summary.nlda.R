`summary.nlda` <-
function(object, ...)
  structure(object, class="summary.nlda")

