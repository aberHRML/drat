
# FIEmspro 
[![Project Status: Inactive - The project has reached a stable, usable state but is no longer being actively developed; support/maintenance will be provided as time allows.](http://www.repostatus.org/badges/0.1.0/inactive.svg)](http://www.repostatus.org/#inactive) [![Build Status](https://travis-ci.org/aberHRML/FIEmspro.svg?branch=master)](https://travis-ci.org/aberHRML/FIEmspro) [![Build status](https://ci.appveyor.com/api/projects/status/40p8dnisqostuvqd/branch/master?svg=true)](https://ci.appveyor.com/project/aberHRML/fiemspro/branch/master)
![License](https://img.shields.io/badge/license-GNU%20GPL%20v2.0-blue.svg "GNU GPL v2.0")
[![DOI](https://zenodo.org/badge/18139/wilsontom/FIEmspro.svg)](https://zenodo.org/badge/latestdoi/18139/wilsontom/FIEmspro)

### Original project page at http://users.aber.ac.uk/jhd


### Installation

Using devtools:

```R
devtools::install_github('aberHRML/FIEmspro')
```
