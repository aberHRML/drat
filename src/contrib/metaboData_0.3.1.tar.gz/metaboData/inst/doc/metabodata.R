## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE----------------------------------------------------------
#  install.packages('metaboData',repos = 'https://aberhrml.github.io/drat/')

## ------------------------------------------------------------------------
library(metaboData)

availableDataSets()

## ------------------------------------------------------------------------
techniques()

## ------------------------------------------------------------------------
dataSets(techniques()[1])

## ------------------------------------------------------------------------
files <- filePaths(
    techniques()[1],
    dataSets(techniques()[1])[1])

length(files)

## ------------------------------------------------------------------------
experimentDescription <- description(
   techniques()[1],
   dataSets(techniques()[1])[1])

str(experimentDescription)

## ------------------------------------------------------------------------
info <- runinfo(
    techniques()[1],
    dataSets(techniques()[1])[1])

head(info)

