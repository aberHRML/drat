library(testthat)
library(metaboData)

test_check("metaboData")
